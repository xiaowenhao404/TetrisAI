function GameManager(level) {
    var gridCanvas = document.getElementById('grid-canvas');
    var nextCanvas = document.getElementById('next-canvas');
    var scoreContainer = document.getElementById("score-container");
    var resetButton = document.getElementById('reset-button');
    var aiButton = document.getElementById('ai-button');
    var gridContext = gridCanvas.getContext('2d');
    var nextContext = nextCanvas.getContext('2d');
    document.addEventListener('keydown', onKeyDown);

    var grid = new Grid(22, 10);
    var rpg = new RandomPieceGenerator(true);
    var ai = new AI({
        heightWeight: 0.510066,
        linesWeight: 0.760666,
        holesWeight: 0.35663,
        bumpinessWeight: 0.184483
    });
    var workingPieces = [null, rpg.nextPiece()];
    var workingPiece = null;
    var isAiActive = true;
    var isKeyEnabled = false;
    var gravityTimer = new Timer(onGravityTimerTick, 500);
    var score = 0;

    var isRandomHeightAdded = false;
    var step= 0 ;
    var skipflag=0;

    // Process start of turn
    const startTurn = () =>  {
        skipflag=0;
        // Shift working pieces·更新方块队列
        for (var i = 0; i < workingPieces.length - 1; i++) {
            workingPieces[i] = workingPieces[i + 1];
        }
        workingPieces[workingPieces.length - 1] = rpg.nextPiece();
        workingPiece = workingPieces[0];

        switch (level) {
            case 1:
                // 正常生成方块
                break;
            case 2:
                if(!isRandomHeightAdded)
                this.addRandomHeight(5);  // 在 level 2，添加随机层
                break;
            case 3:
                this.addRandomHeightEveryXSteps(20);  // 每若干步叠加一层
                break;
            case 4:
                this.randomControlPiece(15);  // 随机控制方块的下落位置
                break;
            case 5:
                if(!isRandomHeightAdded)
                this.addRandomHeight(5);
                this.addRandomHeightEveryXSteps(20);
                this.randomControlPiece(15);
                break;
            default:
                // 正常生成方块
                break;
        }

        // Refresh Graphics
        redrawGridCanvas();
        redrawNextCanvas();

        if (isAiActive) {//如果启用AI模式
            isKeyEnabled = false;//禁止键盘操作
            
            if(!skipflag)
            workingPiece = ai.best(grid, workingPieces);//让AI决策
            else{
                // 将方块的颜色全部设置为黑色
            for (let r = 0; r < workingPiece.cells.length; r++) {
                for (let c = 0; c < workingPiece.cells[r].length; c++) {
                    if (workingPiece.cells[r][c] !== 0) {
                        workingPiece.cells[r][c] = 0x444444; // 设置为黑色
                    }
                }
            }
            }
            startWorkingPieceDropAnimation(function () {
                while (workingPiece.moveDown(grid)); // Drop working piece
                if (!endTurn()) {
                    alert('Game Over!');
                    return;
                }
                startTurn();
            })
        } else {
            isKeyEnabled = true;//开启键盘控制
            gravityTimer.resetForward(500);//重置重力下落定时器
        }
        step++;
    }

    // 随机叠加层（level 2）
    this.addRandomHeight = function (randomHeight) {
        for (let i = 0; i < randomHeight; i++) {
            let row = grid.rows - 1 - i;  // 从底部往上开始
            for (let col = 0; col < grid.columns; col++) {
                if (Math.random() < 0.5) {  // 50%的概率生成方块
                    // 将生成的方块设置为灰色或特定颜色来表示随机生成
                    grid.cells[row][col] = 0x808080;
                }
            }
        }
        isRandomHeightAdded = true; // 设置标记，表示已执行过
    };

    // 每 x 步叠加随机层（level 3）
    this.addRandomHeightEveryXSteps = function (stepInterval) {
        if (step % stepInterval === 0) {  // 每过 `x` 步执行一次
            // 复制上一行的状态到当前行（继承之前的方块）
            for (let i = 1; i < grid.rows; i++){
                for (let j = 0; j < grid.columns; j++) {
                    grid.cells[i-1][j] = grid.cells[i][j];
                }
            }
            // 然后遍历当前行的每个格子，决定是否生成方块
            for (let j = 0; j < grid.columns; j++) {
                if (Math.random() < 0.5) {  // 50%的概率生成方块
                    grid.cells[21][j] = 0x808080;
                }
                else grid.cells[21][j] = 0x000000;
            }
        }
    };

    // 随机控制下一个方块的下落位置（level 4）
    this.randomControlPiece = function (stepInterval) {
        if (step!=0 && step % stepInterval === 0) {  // 随机间隔来控制方块下落位置
            skipflag=1;
            let randomColumn = Math.floor(Math.random() * grid.columns);  // 随机选择一个列

            // 判断当前位置是否能放下方块（没有越界并且没有与已有方块重叠）
            // 使用 grid.valid() 来判断该列是否有效
            pieceWithRandomColumn = workingPiece.clone();
            pieceWithRandomColumn.column = randomColumn;
            
            // 如果不能放置方块，重新随机选择列
            if (!grid.valid(pieceWithRandomColumn)) {
                this.randomControlPiece(stepInterval);  // 递归重新选择列
            } else {
                workingPiece.column = pieceWithRandomColumn.column;  // 如果可以放下方块，则设置新的列位置
            }
        }
    };

    // Graphics·图像
    function intToRGBHexString(v){
        return 'rgb(' + ((v >> 16) & 0xFF) + ',' + ((v >> 8) & 0xFF) + ',' + (v & 0xFF) + ')';
    }//0x表示16进制 函数用于返回颜色值

    function redrawGridCanvas(workingPieceVerticalOffset = 0){//把整个主游戏画布刷新出来 —— 包括已经落地的砖块 + 当前正在操作的那块方块
                    //该参数给当前操作中的方块加一个“下落动画偏移量” 用于AI模拟动画
        gridContext.save();//保存当前画布的设置状态（比如颜色、坐标变换等），便于后面恢复。

        // Clear·清空
        gridContext.clearRect(0, 0, gridCanvas.width, gridCanvas.height);

        // Draw grid·绘制已落地砖块
        for(var r = 2; r < grid.rows; r++){
            for(var c = 0; c < grid.columns; c++){
                if (grid.cells[r][c] != 0){
                    gridContext.fillStyle= intToRGBHexString(grid.cells[r][c]);//根据cell存的颜色信息设置画笔颜色
                    gridContext.fillRect(20 * c, 20 * (r - 2), 20, 20);//实际画一个方块
                    gridContext.strokeStyle="#FFFFFF";//白色
                    gridContext.strokeRect(20 * c, 20 * (r - 2), 20, 20);//画一个白色描边
                }
            }
        }

        // Draw working piece·绘制正在下落的操作方块
        for(var r = 0; r < workingPiece.dimension; r++){
            for(var c = 0; c < workingPiece.dimension; c++){
                if (workingPiece.cells[r][c] != 0){
                    gridContext.fillStyle = intToRGBHexString(workingPiece.cells[r][c]);
                    gridContext.fillRect(20 * (c + workingPiece.column), 20 * ((r + workingPiece.row) - 2) + workingPieceVerticalOffset, 20, 20);
                    gridContext.strokeStyle="#FFFFFF";
                    gridContext.strokeRect(20 * (c + workingPiece.column), 20 * ((r + workingPiece.row) - 2) + workingPieceVerticalOffset, 20, 20);
                }
            }
        }

        gridContext.restore();//还原画笔状态，防止影响后续绘图
    }

    function redrawNextCanvas(){//绘制“下一块方块”的预览区域(后可能改成多方块预览版本)
        nextContext.save();//保存画布状态，和主画布逻辑一致。

        nextContext.clearRect(0, 0, nextCanvas.width, nextCanvas.height);//清空右侧预览画布，准备重新绘制新的“下一块方块”。
        var next = workingPieces[1];
        var xOffset = next.dimension == 2 ? 20 : next.dimension == 3 ? 10 : next.dimension == 4 ? 0 : null;
        var yOffset = next.dimension == 2 ? 20 : next.dimension == 3 ? 20 : next.dimension == 4 ? 10 : null;
        for(var r = 0; r < next.dimension; r++){
            for(var c = 0; c < next.dimension; c++){
                if (next.cells[r][c] != 0){
                    nextContext.fillStyle = intToRGBHexString(next.cells[r][c]);
                    nextContext.fillRect(xOffset + 20 * c, yOffset + 20 * r, 20, 20);
                    nextContext.strokeStyle = "#FFFFFF";
                    nextContext.strokeRect(xOffset + 20 * c, yOffset + 20 * r, 20, 20);
                }
            }
        }

        nextContext.restore();
    }

    function redrawNextCanvas() {
        nextContext.save();

        nextContext.clearRect(0, 0, nextCanvas.width, nextCanvas.height);
        var next = workingPieces[1];
        var xOffset = next.dimension == 2 ? 20 : next.dimension == 3 ? 10 : next.dimension == 4 ? 0 : null;
        var yOffset = next.dimension == 2 ? 20 : next.dimension == 3 ? 20 : next.dimension == 4 ? 10 : null;
        for (var r = 0; r < next.dimension; r++) {
            for (var c = 0; c < next.dimension; c++) {
                if (next.cells[r][c] != 0) {
                    nextContext.fillStyle = intToRGBHexString(next.cells[r][c]);
                    nextContext.fillRect(xOffset + 20 * c, yOffset + 20 * r, 20, 20);
                    nextContext.strokeStyle = "#FFFFFF";
                    nextContext.strokeRect(xOffset + 20 * c, yOffset + 20 * r, 20, 20);
                }
            }
        }

        nextContext.restore();
    }

    function updateScoreContainer() {
        scoreContainer.innerHTML = score.toString();
    }

    // Drop animation
    var workingPieceDropAnimationStopwatch = null;

    function startWorkingPieceDropAnimation(callback = function () { }) {
        // Calculate animation height
        animationHeight = 0;
        _workingPiece = workingPiece.clone();
        while (_workingPiece.moveDown(grid)) {
            animationHeight++;
        }

        var stopwatch = new Stopwatch(function (elapsed) {
            if (elapsed >= animationHeight * 20) {
                stopwatch.stop();
                redrawGridCanvas(20 * animationHeight);
                callback();
                return;
            }

            redrawGridCanvas(20 * elapsed / 20);
        });

        workingPieceDropAnimationStopwatch = stopwatch;
    }

    function cancelWorkingPieceDropAnimation() {
        if (workingPieceDropAnimationStopwatch === null) {
            return;
        }
        workingPieceDropAnimationStopwatch.stop();
        workingPieceDropAnimationStopwatch = null;
    }

    // Process end of turn
    function endTurn() {
        // Add working piece
        grid.addPiece(workingPiece);

        // Clear lines
        score += grid.clearLines();

        // Refresh graphics
        redrawGridCanvas();
        updateScoreContainer();

        return !grid.exceeded();
    }

    // Process gravity tick
    function onGravityTimerTick() {
        // If working piece has not reached bottom
        if (workingPiece.canMoveDown(grid)) {
            workingPiece.moveDown(grid);
            redrawGridCanvas();
            return;
        }

        // Stop gravity if working piece has reached bottom
        gravityTimer.stop();

        // If working piece has reached bottom, end of turn has been processed
        // and game cannot continue because grid has been exceeded
        if (!endTurn()) {
            isKeyEnabled = false;
            alert('Game Over!');
            return;
        }

        // If working piece has reached bottom, end of turn has been processed
        // and game can still continue.
        startTurn();
    }

    // Process keys
    function onKeyDown(event) {
        if (!isKeyEnabled) {
            return;
        }
        switch (event.which) {
            case 32: // spacebar
                isKeyEnabled = false;
                gravityTimer.stop(); // Stop gravity
                startWorkingPieceDropAnimation(function () { // Start drop animation
                    while (workingPiece.moveDown(grid)); // Drop working piece
                    if (!endTurn()) {
                        alert('Game Over!');
                        return;
                    }
                    startTurn();
                });
                break;
            case 40: // down
                gravityTimer.resetForward(500);
                break;
            case 37: //left
                if (workingPiece.canMoveLeft(grid)) {
                    workingPiece.moveLeft(grid);
                    redrawGridCanvas();
                }
                break;
            case 39: //right
                if (workingPiece.canMoveRight(grid)) {
                    workingPiece.moveRight(grid);
                    redrawGridCanvas();
                }
                break;
            case 38: //up
                workingPiece.rotate(grid);
                redrawGridCanvas();
                break;
        }
    }

    aiButton.onclick = function () {
        if (isAiActive) {
            isAiActive = false;
            aiButton.style.backgroundColor = "#f9f9f9";
        } else {
            isAiActive = true;
            aiButton.style.backgroundColor = "#e9e9ff";

            isKeyEnabled = false;
            gravityTimer.stop();
            startWorkingPieceDropAnimation(function () { // Start drop animation
                while (workingPiece.moveDown(grid)); // Drop working piece
                if (!endTurn()) {
                    alert('Game Over!');
                    return;
                }
                startTurn(level);
            });
        }
    }

    resetButton.onclick = function () {
        gravityTimer.stop();
        cancelWorkingPieceDropAnimation();
        grid = new Grid(22, 10);
        rpg = new RandomPieceGenerator();
        workingPieces = [null, rpg.nextPiece()];
        workingPiece = null;
        score = 0;
        isKeyEnabled = true;
        isRandomHeightAdded = false;
        step=0;
        updateScoreContainer();
        startTurn(level);
    }

    aiButton.style.backgroundColor = "#e9e9ff";
    startTurn();
}
